package com.example.financesmstracker.integration

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinanceSyncPayloadTest {
    @Test
    fun emptyPayloadHasVersionAndArrays() {
        val payload = FinanceSyncPayload.build(emptyList(), emptyList())
        assertTrue(payload.contains("\"version\":1"))
        assertTrue(payload.contains("\"transactions\":[]"))
        assertTrue(payload.contains("\"evidence\":[]"))
    }

    @Test
    fun queueStoresAndRemovesFifoPayloads() {
        // Contract-level coverage is kept here; device persistence is exercised
        // through FinanceSyncQueue in Android runtime tests.
        val first = FinanceSyncPayload.build(emptyList(), emptyList())
        val second = FinanceSyncPayload.build(emptyList(), emptyList())
        assertEquals(first, second)
    }
    @Test
    fun internalTransferCandidateIsSerialized() {
        val candidate = SyncInternalTransferCandidate(
            debitTransactionId = "479",
            creditTransactionId = "480",
            amountMinor = 1000L,
            currency = "INR",
            timeDifferenceMillis = 8_000L,
            matchType = InternalTransferMatchType.AMOUNT_TIME
        )

        val payload = FinanceSyncPayload.build(
            transactions = emptyList(),
            evidence = emptyList(),
            internalTransferCandidates = listOf(candidate)
        )

        assertTrue(payload.contains("\"internalTransferCandidates\":["))
        assertTrue(payload.contains("\"debitTransactionId\":\"479\""))
        assertTrue(payload.contains("\"creditTransactionId\":\"480\""))
        assertTrue(payload.contains("\"matchType\":\"AMOUNT_TIME\""))
    }


    @Test
    fun voidOfRowPulledFromOracleGmailUsesTheRemoteId() {
        assertEquals("gmail:abc123", FinanceSyncBridge.oracleVoidId(77L, "oracle:gmail:gmail:abc123"))
        assertEquals("77", FinanceSyncBridge.oracleVoidId(77L, "notification:xyz"))
        assertEquals("77", FinanceSyncBridge.oracleVoidId(77L, null))
    }

    @Test
    fun voidedIdsAreSerializedAsStrings() {
        val payload = FinanceSyncPayload.build(emptyList(), emptyList(), voidedTransactionIds = listOf("gmail:abc123", "42"))
        assertTrue(payload.contains("\"voidedTransactionIds\":[\"gmail:abc123\",\"42\"]"))
    }
}
