package com.example.financesmstracker.parser

import java.util.regex.Pattern

object MerchantParser {
    private val INVALID_MERCHANT_PHRASES = setOf(
        "bank account",
        "your bank account",
        "my account",
        "account",
        "savings",
        "current",
        "self",
        "self account",
        "bank",
        "a/c",
        "ac",
        "your",
        "my",
        "the",
        "a",
        "an",
        "his",
        "her",
        "their",
        "atm",
        "branch",
        "https",
        "http"
    )

    private val TIME_PATTERN = Pattern.compile("^[0-9]{1,2}:[0-9]{2}$")
    private val DATE_PATTERN = Pattern.compile("^[0-9]{1,2}-[a-zA-Z]{3}-[0-9]{2,4}$")

    fun extractMerchantAndVpa(messageBody: String): Pair<String?, String?> {
        var merchant: String? = null
        var vpa: String? = null

        // 1. Check UPI path format: UPI/MerchantName/vpa@handle
        val upiPathMatcher = Pattern.compile("UPI/([^/]+)/([a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+)", Pattern.CASE_INSENSITIVE).matcher(messageBody)
        if (upiPathMatcher.find()) {
            merchant = upiPathMatcher.group(1)?.trim()
            vpa = upiPathMatcher.group(2)?.trim()
        } else {
            // Check multi-segment UPI/P2A/ref/merchant/... (P2M = payment to a merchant)
            val multiUpiMatcher = Pattern.compile("UPI/P2[AM]/[^/]+/([^/\\r\\n]+?)(?=/|\\r?\\n|$)", Pattern.CASE_INSENSITIVE).matcher(messageBody)
            if (multiUpiMatcher.find()) {
                val candidate = multiUpiMatcher.group(1)?.trim()
                if (candidate != null && !candidate.all { it.isDigit() }) {
                    merchant = candidate
                }
            }
        }

        // 2. Standalone VPA
        if (vpa == null) {
            val vpaMatcher = Pattern.compile("([a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+)", Pattern.CASE_INSENSITIVE).matcher(messageBody)
            while (vpaMatcher.find()) {
                val candidate = vpaMatcher.group(1) ?: continue
                val lower = candidate.lowercase()
                if (lower.endsWith(".com") || lower.endsWith(".org") || lower.endsWith(".net") || lower.endsWith(".in")) {
                    if (!lower.contains("upi") && !lower.contains("paytm") && !lower.contains("oksbi") && !lower.contains("okaxis")) {
                        continue
                    }
                }
                if (candidate.contains("@") && !candidate.startsWith("@") && !candidate.endsWith("@")) {
                    vpa = candidate
                    break
                }
            }
        }

        // 3. Axis card spend merchant pattern (timestamp \n MERCHANT \n Avl Limit)
        if (merchant == null) {
            val axisMerchantMatcher = Pattern.compile("(?:[0-9]{2}-[0-9]{2}-[0-9]{2}\\s+[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\\s+[A-Z]+)?)\\s*\\r?\\n\\s*([A-Z0-9\\s._-]+?)\\s*\\r?\\n\\s*(?:Avl|Avbl|Available|Not\\s+you)", Pattern.CASE_INSENSITIVE).matcher(messageBody)
            if (axisMerchantMatcher.find()) {
                val rawAxisMerchant = axisMerchantMatcher.group(1)?.trim()
                if (!rawAxisMerchant.isNullOrBlank() && isValidMerchant(rawAxisMerchant)) {
                    merchant = rawAxisMerchant
                }
            }
        }

        // 3b. Newer Axis card layout: "... IST at\nMERCHANT NAME.\nAvl limit: ..."
        // The merchant sits on its own line after "at" and ends with a period.
        if (merchant == null) {
            val axisAtMatcher = Pattern.compile(
                "[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\\s+[A-Z]+)?\\s+at\\s*\\r?\\n\\s*([^\\r\\n]+?)\\s*\\r?\\n\\s*(?:Avl|Avbl|Available|Not\\s+you)",
                Pattern.CASE_INSENSITIVE
            ).matcher(messageBody)
            if (axisAtMatcher.find()) {
                val raw = cleanMerchant(axisAtMatcher.group(1))
                if (raw.isNotBlank() && isValidMerchant(raw)) {
                    merchant = raw
                }
            }
        }

        // 3c. HDFC deposit layout: "deposited in HDFC Bank A/c XX9591 on 30-OCT-26
        // for FT-A2AINT01-2061157915 - - XXXXXXXXXX2057 - WBS SALARY ACCOUNT.Avl bal ..."
        // The payer/narration is the last readable segment of the "for ..." text.
        if (merchant == null) {
            val depositMatcher = Pattern.compile(
                "deposited\\s+in\\s+.+?\\s+for\\s+(.+?)\\.?\\s*Avl\\s+bal",
                Pattern.CASE_INSENSITIVE or Pattern.DOTALL
            ).matcher(messageBody)
            if (depositMatcher.find()) {
                val narration = depositMatcher.group(1) ?: ""
                val name = cleanMerchant(
                    narration.split(" - ").map { it.trim() }.lastOrNull { it.isNotBlank() }
                )
                // Skip references and masked account numbers; keep only a name.
                val looksLikeName = name.contains(' ') && name.any { it.isLetter() } &&
                    !Regex("^[xX*0-9\\s-]+$").matches(name)
                if (looksLikeName && isValidMerchant(name)) {
                    merchant = name
                }
            }
        }

        // 4. Merchant name after "to", "paid to", "sent to", "towards", "at"
        if (merchant == null) {
            val merchantMatcher = Pattern.compile("(?:to|paid\\s+to|sent\\s+to|towards|at)\\s+([a-zA-Z0-9\\s._-]+?)(?:\\s+(?:Ref\\b|UPI\\b|A/C\\b|on\\b|at\\b|via\\b|IMPS\\b|NEFT\\b|card\\b|ending\\b|\\*|\\d{2}-)|\\s*[\\r\\n]|$)", Pattern.CASE_INSENSITIVE).matcher(messageBody)
            if (merchantMatcher.find()) {
                val rawMerchant = merchantMatcher.group(1)?.let { cleanMerchant(it) }
                if (!rawMerchant.isNullOrBlank() && !rawMerchant.equals("UPI", ignoreCase = true) && !rawMerchant.equals("P2A", ignoreCase = true)) {
                    if (isValidMerchant(rawMerchant)) {
                        merchant = rawMerchant
                    }
                }
            }
        }

        // 5. Fallback for raw identifiers like "82184053ptyes"
        if (merchant == null && vpa == null) {
            val fallbackMatcher = Pattern.compile("(?:to|paid\\s+to|sent\\s+to|at)\\s+([a-zA-Z0-9._-]+)", Pattern.CASE_INSENSITIVE).matcher(messageBody)
            if (fallbackMatcher.find()) {
                val rawFallback = fallbackMatcher.group(1)?.trim()
                if (rawFallback != null && isValidMerchant(rawFallback)) {
                    merchant = rawFallback
                }
            }
        }

        return Pair(merchant, vpa)
    }

    /** Trim whitespace and the sentence-ending period banks put after a merchant name. */
    private fun cleanMerchant(value: String?): String =
        (value ?: "").trim().trimEnd('.', ',').trim()

    private fun isValidMerchant(candidate: String): Boolean {
        val trimmed = candidate.trim()
        val lower = trimmed.lowercase()
        if (INVALID_MERCHANT_PHRASES.contains(lower)) {
            return false
        }
        if (TIME_PATTERN.matcher(trimmed).matches()) {
            return false
        }
        if (DATE_PATTERN.matcher(trimmed).matches()) {
            return false
        }
        if (trimmed.startsWith("http://", ignoreCase = true) || 
            trimmed.startsWith("https://", ignoreCase = true) || 
            lower.contains("://") || 
            lower.contains("www.") ||
            lower.startsWith("https", ignoreCase = true) ||
            lower.startsWith("http", ignoreCase = true)) {
            return false
        }
        if (trimmed.all { it.isDigit() || it.isWhitespace() }) {
            return false
        }
        return true
    }
}
