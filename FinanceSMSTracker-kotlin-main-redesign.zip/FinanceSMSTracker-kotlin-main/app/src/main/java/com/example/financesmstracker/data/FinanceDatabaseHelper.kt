package com.example.financesmstracker.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class FinanceDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    private val appContext: Context = context.applicationContext

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        // Fix the Oracle id boundary before this process inserts anything.
        com.example.financesmstracker.integration.OracleIds.initialize(appContext, db)
    }

    companion object {
        private const val DATABASE_NAME = "finance_tracker.db"
        private const val DATABASE_VERSION = 8

        const val TABLE_TRANSACTIONS = "transactions"
        const val COLUMN_ID = "id"
        const val COLUMN_AMOUNT_PAISE = "amount_paise"
        const val COLUMN_CURRENCY = "currency"
        const val COLUMN_TRANSACTION_TYPE = "transaction_type"
        const val COLUMN_PAYMENT_METHOD = "payment_method"
        const val COLUMN_ACCOUNT_TYPE = "account_type"
        const val COLUMN_BANK = "bank"
        const val COLUMN_MERCHANT_NAME = "merchant_name"
        const val COLUMN_PAYEE_ID = "payee_id"
        const val COLUMN_ACCOUNT_LAST_FOUR = "account_last_four"
        const val COLUMN_REF_NUMBER = "ref_number"
        const val COLUMN_TIMESTAMP = "timestamp"
        const val COLUMN_SMS_HASH = "sms_hash"
        const val COLUMN_CATEGORY = "category"
        const val COLUMN_PARSER_CONFIDENCE = "parser_confidence"
        const val COLUMN_TRANSACTION_STATUS = "status"

        const val TABLE_CATEGORY_MEMORY = "category_memory"
        const val COLUMN_MEMORY_KEY = "memory_key"
        const val COLUMN_MEMORY_CATEGORY = "category"

        const val TABLE_SOURCE_EVIDENCE = "source_evidence"
        const val COLUMN_EVIDENCE_ID = "id"
        const val COLUMN_EVIDENCE_SOURCE_TYPE = "source_type"
        const val COLUMN_EVIDENCE_SOURCE_KEY = "source_key"
        const val COLUMN_EVIDENCE_RECEIVED_AT = "received_at"
        const val COLUMN_EVIDENCE_TRANSACTION_ID = "transaction_id"
        const val COLUMN_EVIDENCE_AMOUNT_PAISE = "amount_paise"
        const val COLUMN_EVIDENCE_CURRENCY = "currency"
        const val COLUMN_EVIDENCE_DIRECTION = "direction"
        const val COLUMN_EVIDENCE_BANK_PROVIDER = "bank_provider"
        const val COLUMN_EVIDENCE_ACCOUNT_LAST_FOUR = "account_last_four"
        const val COLUMN_EVIDENCE_REFERENCE = "reference"
        const val COLUMN_EVIDENCE_CONTENT_HASH = "content_hash"
        const val COLUMN_EVIDENCE_CONFIDENCE = "confidence"
        const val COLUMN_EVIDENCE_STATUS = "status"

        const val TABLE_UNRECOGNIZED_SMS = "unrecognized_sms"
        const val COLUMN_UNRECOGNIZED_ID = "id"
        const val COLUMN_UNRECOGNIZED_SENDER = "sender"
        const val COLUMN_UNRECOGNIZED_RECEIVED_AT = "received_at"
        const val COLUMN_UNRECOGNIZED_CONTENT_HASH = "content_hash"
        const val COLUMN_UNRECOGNIZED_REASON = "reason"
        const val COLUMN_UNRECOGNIZED_STATUS = "status"
        const val COLUMN_UNRECOGNIZED_PREVIEW = "preview"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTransactionsTable = """
            CREATE TABLE $TABLE_TRANSACTIONS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_AMOUNT_PAISE INTEGER NOT NULL,
                $COLUMN_CURRENCY TEXT NOT NULL DEFAULT 'INR',
                $COLUMN_TRANSACTION_TYPE TEXT NOT NULL,
                $COLUMN_PAYMENT_METHOD TEXT NOT NULL,
                $COLUMN_ACCOUNT_TYPE TEXT NOT NULL,
                $COLUMN_BANK TEXT,
                $COLUMN_MERCHANT_NAME TEXT,
                $COLUMN_PAYEE_ID TEXT,
                $COLUMN_ACCOUNT_LAST_FOUR TEXT,
                $COLUMN_REF_NUMBER TEXT,
                $COLUMN_TIMESTAMP INTEGER NOT NULL,
                $COLUMN_SMS_HASH TEXT UNIQUE NOT NULL,
                $COLUMN_CATEGORY TEXT,
                $COLUMN_PARSER_CONFIDENCE REAL NOT NULL,
                $COLUMN_TRANSACTION_STATUS TEXT NOT NULL DEFAULT 'ACTIVE'
            )
        """.trimIndent()

        val createMemoryTable = """
            CREATE TABLE $TABLE_CATEGORY_MEMORY (
                $COLUMN_MEMORY_KEY TEXT PRIMARY KEY,
                $COLUMN_MEMORY_CATEGORY TEXT NOT NULL
            )
        """.trimIndent()

        val createEvidenceTable = """
            CREATE TABLE $TABLE_SOURCE_EVIDENCE (
                $COLUMN_EVIDENCE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_EVIDENCE_SOURCE_TYPE TEXT NOT NULL,
                $COLUMN_EVIDENCE_SOURCE_KEY TEXT UNIQUE NOT NULL,
                $COLUMN_EVIDENCE_RECEIVED_AT INTEGER NOT NULL,
                $COLUMN_EVIDENCE_TRANSACTION_ID INTEGER,
                $COLUMN_EVIDENCE_AMOUNT_PAISE INTEGER NOT NULL,
                $COLUMN_EVIDENCE_CURRENCY TEXT NOT NULL DEFAULT 'INR',
                $COLUMN_EVIDENCE_DIRECTION TEXT NOT NULL,
                $COLUMN_EVIDENCE_BANK_PROVIDER TEXT,
                $COLUMN_EVIDENCE_ACCOUNT_LAST_FOUR TEXT,
                $COLUMN_EVIDENCE_REFERENCE TEXT,
                $COLUMN_EVIDENCE_CONTENT_HASH TEXT NOT NULL,
                $COLUMN_EVIDENCE_CONFIDENCE REAL NOT NULL,
                $COLUMN_EVIDENCE_STATUS TEXT NOT NULL,
                FOREIGN KEY($COLUMN_EVIDENCE_TRANSACTION_ID) REFERENCES $TABLE_TRANSACTIONS($COLUMN_ID) ON DELETE SET NULL
            )
        """.trimIndent()

        val createEvidenceIndex = """
            CREATE INDEX IF NOT EXISTS idx_source_evidence_status_amount 
            ON $TABLE_SOURCE_EVIDENCE($COLUMN_EVIDENCE_STATUS, $COLUMN_EVIDENCE_AMOUNT_PAISE)
        """.trimIndent()

        val createUnrecognizedTable = """
            CREATE TABLE $TABLE_UNRECOGNIZED_SMS (
                $COLUMN_UNRECOGNIZED_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_UNRECOGNIZED_SENDER TEXT NOT NULL,
                $COLUMN_UNRECOGNIZED_RECEIVED_AT INTEGER NOT NULL,
                $COLUMN_UNRECOGNIZED_CONTENT_HASH TEXT UNIQUE NOT NULL,
                $COLUMN_UNRECOGNIZED_REASON TEXT NOT NULL,
                $COLUMN_UNRECOGNIZED_STATUS TEXT NOT NULL DEFAULT 'REVIEW',
                $COLUMN_UNRECOGNIZED_PREVIEW TEXT
            )
        """.trimIndent()

        db.execSQL(createTransactionsTable)
        db.execSQL(createMemoryTable)
        db.execSQL(createEvidenceTable)
        db.execSQL(createEvidenceIndex)
        db.execSQL(createUnrecognizedTable)
    }

    private fun columnExists(db: SQLiteDatabase, table: String, column: String): Boolean {
        db.rawQuery("PRAGMA table_info(${table.replace("'", "''")})", null).use { cursor ->
            val nameIndex = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                if (nameIndex >= 0 && cursor.getString(nameIndex).equals(column, ignoreCase = true)) {
                    return true
                }
            }
        }
        return false
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            val createEvidenceTable = """
                CREATE TABLE IF NOT EXISTS $TABLE_SOURCE_EVIDENCE (
                    $COLUMN_EVIDENCE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_EVIDENCE_SOURCE_TYPE TEXT NOT NULL,
                    $COLUMN_EVIDENCE_SOURCE_KEY TEXT UNIQUE NOT NULL,
                    $COLUMN_EVIDENCE_RECEIVED_AT INTEGER NOT NULL,
                    $COLUMN_EVIDENCE_TRANSACTION_ID INTEGER,
                    $COLUMN_EVIDENCE_AMOUNT_PAISE INTEGER NOT NULL,
                    $COLUMN_EVIDENCE_CURRENCY TEXT NOT NULL DEFAULT 'INR',
                    $COLUMN_EVIDENCE_DIRECTION TEXT NOT NULL,
                    $COLUMN_EVIDENCE_BANK_PROVIDER TEXT,
                    $COLUMN_EVIDENCE_ACCOUNT_LAST_FOUR TEXT,
                    $COLUMN_EVIDENCE_REFERENCE TEXT,
                    $COLUMN_EVIDENCE_CONTENT_HASH TEXT NOT NULL,
                    $COLUMN_EVIDENCE_CONFIDENCE REAL NOT NULL,
                    $COLUMN_EVIDENCE_STATUS TEXT NOT NULL,
                    FOREIGN KEY($COLUMN_EVIDENCE_TRANSACTION_ID) REFERENCES $TABLE_TRANSACTIONS($COLUMN_ID) ON DELETE SET NULL
                )
            """.trimIndent()
            val createEvidenceIndex = """
                CREATE INDEX IF NOT EXISTS idx_source_evidence_status_amount 
                ON $TABLE_SOURCE_EVIDENCE($COLUMN_EVIDENCE_STATUS, $COLUMN_EVIDENCE_AMOUNT_PAISE)
            """.trimIndent()
            db.execSQL(createEvidenceTable)
            db.execSQL(createEvidenceIndex)
        }
        if (oldVersion < 3) {
            if (!columnExists(db, TABLE_TRANSACTIONS, COLUMN_CURRENCY)) {
                db.execSQL("ALTER TABLE $TABLE_TRANSACTIONS ADD COLUMN $COLUMN_CURRENCY TEXT NOT NULL DEFAULT 'INR'")
            }
            if (!columnExists(db, TABLE_SOURCE_EVIDENCE, COLUMN_EVIDENCE_CURRENCY)) {
                db.execSQL("ALTER TABLE $TABLE_SOURCE_EVIDENCE ADD COLUMN $COLUMN_EVIDENCE_CURRENCY TEXT NOT NULL DEFAULT 'INR'")
            }
        }
        if (oldVersion < 4) {
            val createUnrecognizedTable = """
                CREATE TABLE IF NOT EXISTS $TABLE_UNRECOGNIZED_SMS (
                    $COLUMN_UNRECOGNIZED_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_UNRECOGNIZED_SENDER TEXT NOT NULL,
                    $COLUMN_UNRECOGNIZED_RECEIVED_AT INTEGER NOT NULL,
                    $COLUMN_UNRECOGNIZED_CONTENT_HASH TEXT UNIQUE NOT NULL,
                    $COLUMN_UNRECOGNIZED_REASON TEXT NOT NULL,
                    $COLUMN_UNRECOGNIZED_STATUS TEXT NOT NULL DEFAULT 'REVIEW'
                )
            """.trimIndent()
            db.execSQL(createUnrecognizedTable)
        }
        if (oldVersion < 5) {
            // Some installs reached an older schema version without the evidence
            // table actually being present. Re-create it idempotently during
            // upgrade so existing transaction data is preserved.
            val createEvidenceTable = """
                CREATE TABLE IF NOT EXISTS $TABLE_SOURCE_EVIDENCE (
                    $COLUMN_EVIDENCE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_EVIDENCE_SOURCE_TYPE TEXT NOT NULL,
                    $COLUMN_EVIDENCE_SOURCE_KEY TEXT UNIQUE NOT NULL,
                    $COLUMN_EVIDENCE_RECEIVED_AT INTEGER NOT NULL,
                    $COLUMN_EVIDENCE_TRANSACTION_ID INTEGER,
                    $COLUMN_EVIDENCE_AMOUNT_PAISE INTEGER NOT NULL,
                    $COLUMN_EVIDENCE_CURRENCY TEXT NOT NULL DEFAULT 'INR',
                    $COLUMN_EVIDENCE_DIRECTION TEXT NOT NULL,
                    $COLUMN_EVIDENCE_BANK_PROVIDER TEXT,
                    $COLUMN_EVIDENCE_ACCOUNT_LAST_FOUR TEXT,
                    $COLUMN_EVIDENCE_REFERENCE TEXT,
                    $COLUMN_EVIDENCE_CONTENT_HASH TEXT NOT NULL,
                    $COLUMN_EVIDENCE_CONFIDENCE REAL NOT NULL,
                    $COLUMN_EVIDENCE_STATUS TEXT NOT NULL,
                    FOREIGN KEY($COLUMN_EVIDENCE_TRANSACTION_ID) REFERENCES $TABLE_TRANSACTIONS($COLUMN_ID) ON DELETE SET NULL
                )
            """.trimIndent()
            val createEvidenceIndex = """
                CREATE INDEX IF NOT EXISTS idx_source_evidence_status_amount
                ON $TABLE_SOURCE_EVIDENCE($COLUMN_EVIDENCE_STATUS, $COLUMN_EVIDENCE_AMOUNT_PAISE)
            """.trimIndent()
            db.execSQL(createEvidenceTable)
            db.execSQL(createEvidenceIndex)
        }
        if (oldVersion < 6) {
            if (!columnExists(db, TABLE_TRANSACTIONS, COLUMN_TRANSACTION_STATUS)) {
                db.execSQL("ALTER TABLE $TABLE_TRANSACTIONS ADD COLUMN $COLUMN_TRANSACTION_STATUS TEXT NOT NULL DEFAULT 'ACTIVE'")
            }
        }
        if (oldVersion < 7) {
            // Truecaller was removed from the financial evidence pipeline.
            // Delete only legacy Truecaller evidence; transaction history itself
            // is preserved.
            db.execSQL(
                "DELETE FROM $TABLE_SOURCE_EVIDENCE WHERE $COLUMN_EVIDENCE_SOURCE_TYPE = 'TRUECALLER'"
            )
        }
        if (oldVersion < 8) {
            // Short on-device preview so Review can show what the message said.
            // Cleared when the item is dismissed or resolved.
            if (!columnExists(db, TABLE_UNRECOGNIZED_SMS, COLUMN_UNRECOGNIZED_PREVIEW)) {
                db.execSQL("ALTER TABLE $TABLE_UNRECOGNIZED_SMS ADD COLUMN $COLUMN_UNRECOGNIZED_PREVIEW TEXT")
            }
        }
    }
}
