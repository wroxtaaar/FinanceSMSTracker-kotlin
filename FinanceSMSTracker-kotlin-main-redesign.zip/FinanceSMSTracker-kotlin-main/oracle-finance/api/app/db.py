import os
import sqlite3
from contextlib import contextmanager

DB_PATH = os.getenv("DATABASE_PATH", "/app/data/finance.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY, amount_minor INTEGER NOT NULL, currency TEXT NOT NULL,
  type TEXT NOT NULL, payment_method TEXT NOT NULL, account_type TEXT NOT NULL,
  bank TEXT, merchant_or_payee TEXT, account_last4 TEXT, reference TEXT,
  timestamp INTEGER NOT NULL, category TEXT NOT NULL, confidence REAL NOT NULL, duplicate_of TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS evidence (
  id TEXT PRIMARY KEY, source_type TEXT NOT NULL, source_id TEXT NOT NULL, status TEXT NOT NULL,
  observed_at INTEGER NOT NULL, transaction_id TEXT, matched_transaction_id TEXT,
  amount_minor INTEGER, currency TEXT, direction TEXT, bank_provider TEXT, account_last4 TEXT,
  reference TEXT, content_hash TEXT, confidence REAL, created_at INTEGER NOT NULL,
  UNIQUE(source_type, source_id)
);
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, currency TEXT NOT NULL, account_type TEXT NOT NULL,
  bank TEXT, last4 TEXT, opening_balance_minor INTEGER NOT NULL DEFAULT 0, balance_minor INTEGER NOT NULL DEFAULT 0,
  bill_balance_minor INTEGER NOT NULL DEFAULT 0, balance_reconciled_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS splitwise_receivables (
  id TEXT PRIMARY KEY, description TEXT NOT NULL, amount_minor INTEGER NOT NULL, currency TEXT NOT NULL,
  splitwise_expense_id TEXT, status TEXT NOT NULL DEFAULT 'OPEN', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS splitwise_baseline_rows (
  currency TEXT NOT NULL, transaction_id TEXT NOT NULL, delta_minor INTEGER NOT NULL,
  PRIMARY KEY(currency, transaction_id)
);
CREATE TABLE IF NOT EXISTS expense_links (
  transaction_id TEXT PRIMARY KEY, expense_id TEXT NOT NULL, description TEXT,
  group_id TEXT, payer_id TEXT, amount_minor INTEGER NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS expense_handled (
  transaction_id TEXT PRIMARY KEY, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS manual_splitwise_total (
  currency TEXT PRIMARY KEY, amount_minor INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS splitwise_adjustments (
  transaction_id TEXT PRIMARY KEY, currency TEXT NOT NULL, delta_minor INTEGER NOT NULL,
  applied_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS internal_transfers (
  id TEXT PRIMARY KEY, debit_transaction_id TEXT NOT NULL, credit_transaction_id TEXT NOT NULL,
  currency TEXT NOT NULL, amount_minor INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'MATCHED',
  reason TEXT NOT NULL, splitwise_neutralized INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL, UNIQUE(debit_transaction_id, credit_transaction_id)
);
CREATE TABLE IF NOT EXISTS splitwise_rules (
  id TEXT PRIMARY KEY, merchant_pattern TEXT NOT NULL, group_id INTEGER NOT NULL,
  split_mode TEXT NOT NULL DEFAULT 'EQUAL', user_shares_json TEXT, enabled INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS emi_loans (
  id TEXT PRIMARY KEY, label TEXT NOT NULL, bank TEXT NOT NULL, debit_last4 TEXT NOT NULL,
  loan_last4 TEXT NOT NULL, emi_minor INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'INR',
  start_day INTEGER NOT NULL DEFAULT 1, due_day INTEGER NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS splitwise_expenses (
  transaction_id TEXT PRIMARY KEY, splitwise_expense_id TEXT, status TEXT NOT NULL, error TEXT,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS review_queue (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, transaction_id TEXT, evidence_id TEXT, reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'OPEN', created_at INTEGER NOT NULL, resolved_at INTEGER
);
CREATE TABLE IF NOT EXISTS gmail_attachments (
  id TEXT PRIMARY KEY, message_id TEXT NOT NULL, filename TEXT NOT NULL, mime_type TEXT,
  content_hash TEXT NOT NULL, bank TEXT, status TEXT NOT NULL,
  transaction_count INTEGER NOT NULL DEFAULT 0, error TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS gmail_messages (
  id TEXT PRIMARY KEY, thread_id TEXT, internal_date INTEGER, sender TEXT, subject TEXT,
  fingerprint TEXT UNIQUE, status TEXT NOT NULL DEFAULT 'SEEN', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS card_bill_evidence (
  id TEXT PRIMARY KEY, source_type TEXT NOT NULL, source_key TEXT NOT NULL,
  observed_at INTEGER NOT NULL, amount_minor INTEGER, currency TEXT NOT NULL DEFAULT 'INR',
  bank TEXT, account_last4 TEXT, account_last2 TEXT, confidence REAL NOT NULL,
  applied INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL,
  UNIQUE(source_type, source_key)
);
CREATE INDEX IF NOT EXISTS idx_card_bill_evidence_card
  ON card_bill_evidence(bank, account_last4, account_last2, observed_at);
CREATE TABLE IF NOT EXISTS balance_adjustments (
  transaction_id TEXT PRIMARY KEY, account_id TEXT NOT NULL, delta_minor INTEGER NOT NULL,
  applied_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gmail_attachments_message ON gmail_attachments(message_id);\nCREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp);
CREATE INDEX IF NOT EXISTS idx_transactions_match ON transactions(amount_minor,currency,timestamp);
CREATE INDEX IF NOT EXISTS idx_evidence_transaction ON evidence(transaction_id);
CREATE INDEX IF NOT EXISTS idx_evidence_match ON evidence(amount_minor,currency,observed_at);
CREATE INDEX IF NOT EXISTS idx_accounts_type ON accounts(account_type);
CREATE INDEX IF NOT EXISTS idx_splitwise_status ON splitwise_receivables(status);
CREATE INDEX IF NOT EXISTS idx_review_status ON review_queue(status);
CREATE INDEX IF NOT EXISTS idx_balance_adjustments_account ON balance_adjustments(account_id);
CREATE INDEX IF NOT EXISTS idx_splitwise_adjustments_currency ON splitwise_adjustments(currency);
"""

@contextmanager
def connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")

    # The isolated Sheets service is SQL read-only, but SQLite WAL still
    # needs filesystem access to its -wal/-shm sidecar files. The Compose
    # override therefore keeps the database directory writable while this
    # connection enables SQLite query_only mode. The normal API/worker path
    # remains unchanged.
    read_only = os.getenv("DATABASE_READ_ONLY", "").strip().lower() in {"1", "true", "yes"}
    if read_only:
        conn.execute("PRAGMA query_only=ON")
    else:
        conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def _card_bank_label(bank):
    return {"ICICI": "ICICI", "SBI": "SBI", "HDFC": "HDFC",
            "INDUSIND": "IndusInd"}.get(bank, bank.title())

def init_db():
    with connection() as conn:
        conn.executescript(SCHEMA)
        # The Expense-app tables were first called splits_*: move any rows over once.
        tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "splits_links" in tables:
            conn.execute(
                "INSERT OR IGNORE INTO expense_links(transaction_id,expense_id,description,group_id,payer_id,amount_minor,created_at)"
                " SELECT transaction_id,splits_id,description,group_id,payer_id,amount_minor,created_at FROM splits_links")
            conn.execute("DROP TABLE splits_links")
        if "splits_handled" in tables:
            conn.execute("INSERT OR IGNORE INTO expense_handled(transaction_id,created_at) SELECT transaction_id,created_at FROM splits_handled")
            conn.execute("DROP TABLE splits_handled")

        # The user's Axis loan: the EMI is auto-debited from the Axis account on
        # the 10th. It is reserved in "true available" from the 1st, and its
        # debit and loan-account credit stay out of Splitwise. INSERT OR IGNORE
        # keeps later edits and makes created_at the date the rule starts.
        conn.execute(
            """INSERT OR IGNORE INTO emi_loans(
                id,label,bank,debit_last4,loan_last4,emi_minor,currency,start_day,due_day,enabled,created_at
            ) VALUES('axis-loan-8590','Axis loan','AXIS','3370','8590',1110000,'INR',1,10,1,?)""",
            (int(__import__("time").time() * 1000),),
        )

        transaction_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(transactions)").fetchall()
        }
        if "duplicate_of" not in transaction_columns:
            conn.execute("ALTER TABLE transactions ADD COLUMN duplicate_of TEXT")

        if "status" not in transaction_columns:
            conn.execute("ALTER TABLE transactions ADD COLUMN status TEXT NOT NULL DEFAULT 'ACTIVE'")

        transfer_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(internal_transfers)").fetchall()
        }
        if "splitwise_neutralized" not in transfer_columns:
            conn.execute(
                "ALTER TABLE internal_transfers ADD COLUMN splitwise_neutralized INTEGER NOT NULL DEFAULT 0"
            )

        splitwise_total_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(manual_splitwise_total)").fetchall()
        }
        # A manual Splitwise total is a baseline: the amount the user set and
        # the ledger-wide Splitwise sum at that moment. Rebuilds then only add
        # what changed in the ledger afterwards instead of overwriting the
        # user's value with the whole history.
        if "baseline_amount_minor" not in splitwise_total_columns:
            conn.execute("ALTER TABLE manual_splitwise_total ADD COLUMN baseline_amount_minor INTEGER")
        if "baseline_ledger_minor" not in splitwise_total_columns:
            conn.execute("ALTER TABLE manual_splitwise_total ADD COLUMN baseline_ledger_minor INTEGER")
        if "baseline_set_at" not in splitwise_total_columns:
            conn.execute("ALTER TABLE manual_splitwise_total ADD COLUMN baseline_set_at INTEGER")

        account_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(accounts)").fetchall()
        }
        if "opening_balance_minor" not in account_columns:
            conn.execute("ALTER TABLE accounts ADD COLUMN opening_balance_minor INTEGER")

        if "bill_balance_minor" not in account_columns:
            conn.execute("ALTER TABLE accounts ADD COLUMN bill_balance_minor INTEGER NOT NULL DEFAULT 0")
            # Existing credit-card accounts only had one live outstanding balance.
            # Seed the new bill bucket from that value so the new two-column UI
            # starts without changing the existing ledger total.
            conn.execute(
                """UPDATE accounts
                   SET bill_balance_minor = balance_minor
                 WHERE account_type='CREDIT_CARD'"""
            )

        if "balance_reconciled_at" not in account_columns:
            conn.execute("ALTER TABLE accounts ADD COLUMN balance_reconciled_at INTEGER NOT NULL DEFAULT 0")

        # A card bill payment locks the statement bill: statements observed on
        # or before this moment can no longer overwrite it.
        if "bill_locked_at" not in account_columns:
            conn.execute("ALTER TABLE accounts ADD COLUMN bill_locked_at INTEGER NOT NULL DEFAULT 0")

        # Existing accounts predate the opening-balance field. Reconstruct the
        # opening snapshot from their current balance and already-applied
        # transaction adjustments so upgrades preserve the live balance.
        conn.execute(
            """UPDATE accounts
               SET opening_balance_minor = balance_minor - COALESCE(
                   (SELECT SUM(delta_minor) FROM balance_adjustments WHERE account_id=accounts.id), 0
               )
             WHERE opening_balance_minor IS NULL"""
        )

        # One-time repair: the live ledger used to store card spends with the
        # bank sign (lowering the amount owed) while statement imports used the
        # card sign. Fix only the adjustments whose sign disagrees with their
        # transaction, and move the card balance by the same difference.
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if not conn.execute("SELECT 1 FROM applied_migrations WHERE name='card_adjustment_sign'").fetchone():
            wrong = conn.execute(
                """SELECT ba.transaction_id AS tid, ba.account_id AS aid, ba.delta_minor AS delta,
                          t.amount_minor AS amount, t.type AS type
                   FROM balance_adjustments ba
                   JOIN accounts a ON a.id = ba.account_id AND a.account_type='CREDIT_CARD'
                   JOIN transactions t ON t.id = ba.transaction_id
                   WHERE t.type IN ('DEBIT','CREDIT')"""
            ).fetchall()
            for row in wrong:
                expected = row["amount"] if row["type"] == "DEBIT" else -row["amount"]
                if row["delta"] == expected:
                    continue
                conn.execute(
                    "UPDATE balance_adjustments SET delta_minor=? WHERE transaction_id=?",
                    (expected, row["tid"]),
                )
                conn.execute(
                    "UPDATE accounts SET balance_minor = balance_minor + ? WHERE id=?",
                    (expected - row["delta"], row["aid"]),
                )
            conn.execute("INSERT INTO applied_migrations(name) VALUES('card_adjustment_sign')")

        # Keep the configured credit-card roster available in the ledger even
        # before the user enters the opening/outstanding balance. INSERT OR
        # IGNORE makes this safe on every startup and preserves existing values.
        configured_cards = [
            ("icici-card-8001", "ICICI Credit Card", "INR", "CREDIT_CARD", "ICICI", "8001"),
            ("hdfc-card-5304", "HDFC Credit Card", "INR", "CREDIT_CARD", "HDFC", "5304"),
            ("sbi-card-7345", "SBI Credit Card", "INR", "CREDIT_CARD", "SBI", "7345"),
        ]
        for bank, last4 in (
            ("ICICI", "1012"), ("ICICI", "0005"), ("ICICI", "6002"), ("ICICI", "9001"),
            ("SBI", "0065"), ("INDUSIND", "3526"),
        ):
            configured_cards.append((
                f"{bank.lower()}-card-{last4}", f"{_card_bank_label(bank)} Credit Card",
                "INR", "CREDIT_CARD", bank, last4,
            ))
        # Co-branded cards are issued by Axis: their SMS/e-mail alerts say
        # "Axis Bank Credit Card", so the bank must be AXIS or no spend matches.
        configured_cards.append(("airtel-card-9206", "Airtel Axis Credit Card", "INR", "CREDIT_CARD", "AXIS", "9206"))
        configured_cards.append(("ace-card-1175", "Axis Ace Credit Card", "INR", "CREDIT_CARD", "AXIS", "1175"))
        now = __import__("time").time()
        now_ms = int(now * 1000)
        for account_id, name, currency, account_type, bank, last4 in configured_cards:
            conn.execute(
                """INSERT OR IGNORE INTO accounts(
                    id,name,currency,account_type,bank,last4,opening_balance_minor,
                    balance_minor,bill_balance_minor,balance_reconciled_at,updated_at
                ) VALUES(?,?,?,?,?,?,0,0,0,0,?)""",
                (account_id, name, currency, account_type, bank, last4, now_ms),
            )
            # Names no longer embed the last four (the app shows them separately).
            conn.execute("UPDATE accounts SET name=?, bank=? WHERE id=?", (name, bank, account_id))


        transaction_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(transactions)").fetchall()
        }
        for name, sql_type in {
            "orig_amount_minor": "INTEGER",
            "orig_currency": "TEXT",
            "fx_rate": "REAL",
            "fx_exact": "INTEGER DEFAULT 0",
            "splitwise_amount_minor": "INTEGER",
        }.items():
            if name not in transaction_columns:
                conn.execute(f"ALTER TABLE transactions ADD COLUMN {name} {sql_type}")

        evidence_columns = {
            row["name"] for row in conn.execute("PRAGMA table_info(evidence)").fetchall()
        }
        migrations = {
            "duplicate_of":"TEXT",
            "amount_minor":"INTEGER",
            "currency":"TEXT",
            "direction":"TEXT",
            "bank_provider":"TEXT",
            "account_last4":"TEXT",
            "reference":"TEXT",
            "content_hash":"TEXT",
            "confidence":"REAL",
        }
        for name, sql_type in migrations.items():
            if name not in evidence_columns:
                conn.execute(f"ALTER TABLE evidence ADD COLUMN {name} {sql_type}")
