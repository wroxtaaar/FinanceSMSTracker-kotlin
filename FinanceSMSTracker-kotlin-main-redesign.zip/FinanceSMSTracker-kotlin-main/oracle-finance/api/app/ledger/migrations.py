"""One-time data migrations, each recorded in applied_migrations."""

from ..db import connection
from .splitwise import _ledger_splitwise_total


def migrate_gmail_default_category():
    """One-time: e-mail debits created after OTHER became an opt-out.

    They were given OTHER by default and so silently dropped out of Splitwise.
    Rows created before the opt-out migration were already absorbed into the
    baseline, so only later ones are switched to the normal default. The
    server ignores category edits on gmail: rows, so no user choice is lost.
    """
    opt_out_migrated_at_ms = 1792296720000  # 2026-10-18T04:12Z
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='gmail_default_category'"
        ).fetchone():
            return 0
        changed = conn.execute(
            """UPDATE transactions SET category='GROCERIES'
               WHERE id LIKE 'gmail:%' AND UPPER(category)='OTHER' AND type='DEBIT'
                 AND created_at > ?""",
            (opt_out_migrated_at_ms,),
        ).rowcount
        conn.execute("INSERT INTO applied_migrations(name) VALUES('gmail_default_category')")
        return changed


def migrate_splitwise_other_optout():
    """One-time: keep the Splitwise value steady when OTHER became an opt-out.

    Before, every row counted toward Splitwise whatever its category; many
    older rows carry OTHER only as a default. Treating OTHER as an opt-out
    would silently subtract all of them. Shift the baseline by the difference
    so the shown value is unchanged; only later category edits move it.
    """
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='splitwise_other_optout'"
        ).fetchone():
            return False
        for row in conn.execute(
            """SELECT currency,baseline_ledger_minor FROM manual_splitwise_total
               WHERE baseline_amount_minor IS NOT NULL AND baseline_ledger_minor IS NOT NULL"""
        ).fetchall():
            cur = row["currency"]
            shift = _ledger_splitwise_total(conn, cur) - _ledger_splitwise_total(conn, cur, honor_other=False)
            conn.execute(
                "UPDATE manual_splitwise_total SET baseline_ledger_minor=? WHERE currency=?",
                (int(row["baseline_ledger_minor"]) + shift, cur),
            )
        conn.execute("INSERT INTO applied_migrations(name) VALUES('splitwise_other_optout')")
        return True


def migrate_card_bill_reread(window_days=45, now_ms_value=None):
    """One-time: re-derive recent card bills with the corrected parsers.

    Earlier parsers read some statements wrongly (an ICICI bill came out as
    1.00). A parsed attachment or e-mail is never revisited, and a wrong bill
    record could not be replaced. Clear the recent bill records and queue the
    recent statement e-mails to be read again; the Gmail scan then rebuilds them.
    """
    import time
    now = int(now_ms_value if now_ms_value is not None else time.time() * 1000)
    cutoff = now - window_days * 24 * 60 * 60 * 1000
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='card_bill_reread'"
        ).fetchone():
            return 0
        conn.execute(
            """DELETE FROM card_bill_evidence
               WHERE source_type IN ('GMAIL','GMAIL_STATEMENT_PDF') AND observed_at>=?""",
            (cutoff,),
        )
        queued = conn.execute(
            """UPDATE gmail_messages SET status='PENDING'
               WHERE status='PARSED' AND internal_date>=?
                 AND LOWER(COALESCE(subject,'')) LIKE '%statement%'""",
            (cutoff,),
        ).rowcount
        conn.execute("INSERT INTO applied_migrations(name) VALUES('card_bill_reread')")
        return queued


def migrate_splitwise_salary_optout():
    """One-time: keep the Splitwise value steady when SALARY credits became opt-out.

    A salary credit used to lower Splitwise like any other credit. Treating it
    as income would silently add back every salary already recorded. Shift the
    baseline by the difference so the shown value is unchanged; only salary
    received from now on stays out of it.
    """
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='splitwise_salary_optout'"
        ).fetchone():
            return False
        for row in conn.execute(
            """SELECT currency,baseline_ledger_minor FROM manual_splitwise_total
               WHERE baseline_amount_minor IS NOT NULL AND baseline_ledger_minor IS NOT NULL"""
        ).fetchall():
            cur = row["currency"]
            shift = _ledger_splitwise_total(conn, cur) - _ledger_splitwise_total(conn, cur, honor_salary=False)
            conn.execute(
                "UPDATE manual_splitwise_total SET baseline_ledger_minor=? WHERE currency=?",
                (int(row["baseline_ledger_minor"]) + shift, cur),
            )
        conn.execute("INSERT INTO applied_migrations(name) VALUES('splitwise_salary_optout')")
        return True


def migrate_splitwise_statement_rule():
    """One-time: keep Splitwise steady when the statement-row exclusion became permanent.

    Editing a bank balance again used to let earlier-excluded statement rows
    back into the Splitwise sum. Shift the baseline by the difference between
    the two rules so the value shown now does not move.
    """
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='splitwise_statement_rule'"
        ).fetchone():
            return False
        for row in conn.execute(
            """SELECT currency,baseline_ledger_minor FROM manual_splitwise_total
               WHERE baseline_amount_minor IS NOT NULL AND baseline_ledger_minor IS NOT NULL"""
        ).fetchall():
            cur = row["currency"]
            shift = _ledger_splitwise_total(conn, cur) - _ledger_splitwise_total(conn, cur, legacy_statement_rule=True)
            conn.execute(
                "UPDATE manual_splitwise_total SET baseline_ledger_minor=? WHERE currency=?",
                (int(row["baseline_ledger_minor"]) + shift, cur),
            )
        conn.execute("INSERT INTO applied_migrations(name) VALUES('splitwise_statement_rule')")
        return True


def migrate_statement_reconciled_reversal():
    """One-time: undo statement rows replayed into an already-verified balance.

    A statement imported after a manual balance edit used to be applied row by
    row, double counting days the edited balance already covered. Reverse the
    balance effect of exactly those rows (statement rows dated on or before the
    account's last manual edit but stored after it). Splitwise follows, since
    statement rows without a balance effect no longer count toward it.
    """
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='statement_reconciled_reversal'"
        ).fetchone():
            return 0
        rows = conn.execute(
            """SELECT ba.transaction_id, ba.account_id, ba.delta_minor
               FROM balance_adjustments ba
               JOIN transactions t ON t.id = ba.transaction_id
               JOIN accounts a ON a.id = ba.account_id
               WHERE t.id LIKE 'statement:%'
                 AND a.balance_reconciled_at > 0
                 AND t.timestamp <= a.balance_reconciled_at
                 AND t.created_at > a.balance_reconciled_at"""
        ).fetchall()
        for r in rows:
            conn.execute("UPDATE accounts SET balance_minor=balance_minor-? WHERE id=?",
                         (r["delta_minor"], r["account_id"]))
            conn.execute("DELETE FROM balance_adjustments WHERE transaction_id=?", (r["transaction_id"],))
        conn.execute("INSERT INTO applied_migrations(name) VALUES('statement_reconciled_reversal')")
        return len(rows)


def migrate_card_bill_pdf_rederive(now_ms_value=None):
    """One-time: drop recent PDF bill evidence so it is read again.

    PDF totals read before the amount rules were tightened could be wrong (a
    year taken as the amount). That evidence outranks the e-mail total, so the
    wrong figure would never be corrected. Statements from the last 8 days are
    re-read on the next Gmail sync, which records the evidence afresh.
    """
    import time
    now = int(now_ms_value if now_ms_value is not None else time.time() * 1000)
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute(
            "SELECT 1 FROM applied_migrations WHERE name='card_bill_pdf_rederive_v2'"
        ).fetchone():
            return 0
        removed = conn.execute(
            "DELETE FROM card_bill_evidence WHERE source_type='GMAIL_STATEMENT_PDF' AND observed_at>=?",
            (now - 8 * 86_400_000,),
        ).rowcount
        conn.execute("INSERT INTO applied_migrations(name) VALUES('card_bill_pdf_rederive_v2')")
        return removed


def migrate_remove_closed_card(bank, last4):
    """One-time: drop a card the user has closed from the roster.

    Only a card whose outstanding is zero is removed, together with its balance
    adjustments and bill evidence. Transactions stay in the history untouched,
    so Splitwise and past rows do not move. A card still owing money is left
    in place and the removal is retried at the next start.
    """
    name = f"remove_closed_card:{bank}:{last4}"
    with connection() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS applied_migrations (name TEXT PRIMARY KEY)")
        if conn.execute("SELECT 1 FROM applied_migrations WHERE name=?", (name,)).fetchone():
            return False
        accounts = conn.execute(
            "SELECT id,balance_minor FROM accounts WHERE account_type='CREDIT_CARD' AND bank=? AND TRIM(COALESCE(last4,''))=?",
            (bank, last4),
        ).fetchall()
        if any(int(a["balance_minor"] or 0) != 0 for a in accounts):
            return False
        for account in accounts:
            conn.execute("DELETE FROM balance_adjustments WHERE account_id=?", (account["id"],))
            conn.execute("DELETE FROM accounts WHERE id=?", (account["id"],))
        conn.execute("DELETE FROM card_bill_evidence WHERE bank=? AND account_last4=?", (bank, last4))
        conn.execute("INSERT INTO applied_migrations(name) VALUES(?)", (name,))
        return bool(accounts)
