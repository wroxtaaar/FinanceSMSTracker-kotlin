"""Splitwise: per-row deltas, derived total (baseline + ledger change), rules and expenses."""

from ..db import connection
from .common import _resolve_transaction_row, is_provisional_row, now_ms
from .emi import excluded_from_splitwise, list_loans


def splitwise_delta(account_type, transaction_type, amount_minor, category=None, exclude_salary=True,
                    salary_share_minor=None):
    """Return the Splitwise effect implied by the final ledger movement.

    Splitwise is deliberately derived from the same ledger movement as the
    account balance, not from a second set of expense rules. The one category
    that matters is OTHER: the user's explicit "keep this out of Splitwise".
    A SALARY credit is income, not someone settling a shared expense, so it
    is kept out by default; the user can choose how much of a given salary
    should count (salary_share_minor, capped at the credited amount).

    Bank account:
      DEBIT  -> bank -X, so Splitwise +X
      CREDIT -> bank +X, so Splitwise -X

    Credit card outstanding:
      DEBIT  -> outstanding +X, so Splitwise +X
      CREDIT -> outstanding -X, so Splitwise -X

    This also makes transfers self-cancelling:
      bank debit +X + matching bank/card credit -X = 0.
    """
    amount = int(amount_minor)
    account_type = str(account_type or "").strip().upper()
    transaction_type = str(transaction_type or "").strip().upper()

    category_name = str(category or "").strip().upper()
    if category_name == "OTHER":
        return 0
    if exclude_salary and category_name == "SALARY" and transaction_type == "CREDIT":
        if salary_share_minor is None or account_type != "BANK_ACCOUNT":
            return 0
        return -max(0, min(int(salary_share_minor), amount))

    if account_type in ("BANK_ACCOUNT", "CREDIT_CARD"):
        return amount if transaction_type == "DEBIT" else -amount if transaction_type == "CREDIT" else 0
    return 0


def splitwise_delta_for_transaction(t):
    return splitwise_delta(t.accountType, t.type, t.amountMinor, t.category)


def set_manual_splitwise_total(currency, amount_minor):
    with connection() as conn:
        # Record the ledger-wide sum at this moment so later rebuilds only add
        # what changes after the user's reset.
        entries = list(_ledger_splitwise_entries(conn, currency))
        ledger = sum(delta for _r, delta in entries)
        # Remember each row's effect so later edits to old rows can be named.
        conn.execute("DELETE FROM splitwise_baseline_rows WHERE currency=?", (currency,))
        conn.executemany(
            "INSERT OR REPLACE INTO splitwise_baseline_rows(currency,transaction_id,delta_minor) VALUES(?,?,?)",
            [(currency, str(r["id"]), delta) for r, delta in entries if delta],
        )
        conn.execute(
            """INSERT INTO manual_splitwise_total
                   (currency, amount_minor, updated_at, baseline_amount_minor, baseline_ledger_minor, baseline_set_at)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(currency) DO UPDATE SET
                 amount_minor=excluded.amount_minor,
                 updated_at=excluded.updated_at,
                 baseline_amount_minor=excluded.baseline_amount_minor,
                 baseline_ledger_minor=excluded.baseline_ledger_minor,
                 baseline_set_at=excluded.baseline_set_at""",
            (currency, int(amount_minor), now_ms(), int(amount_minor), ledger, now_ms())
        )


def apply_splitwise_contribution(conn, t, applied_at=None):
    """Apply a transaction's Splitwise delta exactly once.

    Gmail transactions are authoritative when no SMS/notification canonical
    row exists. They therefore need the same signed Splitwise effect as local
    transactions. A separate adjustment row makes that effect reversible if a
    later SMS/notification proves the Gmail row was a duplicate.
    """
    transaction_id = str(getattr(t, "id", None) or "")
    if not transaction_id:
        return False

    delta = splitwise_delta_for_transaction(t)
    if not delta:
        return False

    applied_at = int(applied_at or now_ms())
    inserted = conn.execute(
        """INSERT OR IGNORE INTO splitwise_adjustments
           (transaction_id,currency,delta_minor,applied_at)
           VALUES(?,?,?,?)""",
        (transaction_id, t.currency, delta, applied_at),
    )
    # Only the reversible record is kept; the shown total is derived from the ledger.
    return bool(inserted.rowcount)


def _ledger_splitwise_entries(conn, cur, honor_other=True, honor_salary=True, legacy_statement_rule=False):
    """Yield (row, delta) for every canonical bank/card movement that counts toward Splitwise.

    Only active, canonical transactions that actually affect a bank/card
    balance are included. A bank/card transfer naturally cancels because its
    two ledger effects have opposite signs; only the OTHER category (explicit
    opt-out) is consulted.

    Statement rows without a balance effect (dated at or before the account's
    last manual balance edit) never count. The test must not depend on when the
    row was stored: a later manual edit moves balance_reconciled_at forward and
    would otherwise let those rows back in and shift Splitwise.
    """
    rows = conn.execute(
        """SELECT id,amount_minor,currency,type,account_type,payment_method,
                  bank,merchant_or_payee,account_last4,reference,
                  timestamp,category,confidence,splitwise_amount_minor,created_at
           FROM transactions
           WHERE status='ACTIVE'
             AND duplicate_of IS NULL
             AND currency=?
             AND account_type IN ('BANK_ACCOUNT','CREDIT_CARD')
             AND NOT (id LIKE 'statement:%'
                      AND NOT EXISTS (SELECT 1 FROM balance_adjustments b WHERE b.transaction_id=transactions.id)
                      AND EXISTS (SELECT 1 FROM accounts a
                                  WHERE a.account_type=transactions.account_type
                                    AND TRIM(COALESCE(a.last4,''))=TRIM(COALESCE(transactions.account_last4,''))
                                    AND a.balance_reconciled_at>0
                                    AND transactions.timestamp<=a.balance_reconciled_at
                                    {created_clause}))""".format(
            created_clause="AND transactions.created_at>a.balance_reconciled_at" if legacy_statement_rule else ""
        ),
        (cur,),
    ).fetchall()

    # Both legs of a matched own-account transfer cancel by definition.
    # Excluding them as a pair keeps a provisional leg (which is skipped
    # below) from leaving its partner's contribution behind.
    transfer_leg_ids = set()
    for transfer in conn.execute(
        """SELECT debit_transaction_id,credit_transaction_id
           FROM internal_transfers WHERE status='MATCHED'"""
    ).fetchall():
        for leg in (transfer["debit_transaction_id"], transfer["credit_transaction_id"]):
            resolved = _resolve_transaction_row(conn, leg)
            if resolved is not None:
                transfer_leg_ids.add(str(resolved["id"]))

    loans = list_loans(conn, cur)
    for row in rows:
        if str(row["id"]) in transfer_leg_ids:
            continue
        if loans and excluded_from_splitwise(loans, row):
            continue
        if is_provisional_row(row):
            continue
        category = row["category"]
        if not honor_other and str(category or "").strip().upper() == "OTHER":
            category = None
        yield row, splitwise_delta(
            row["account_type"],
            row["type"],
            row["amount_minor"],
            category,
            exclude_salary=honor_salary,
            salary_share_minor=row["splitwise_amount_minor"] if honor_salary else None,
        )


def _ledger_splitwise_total(conn, cur, **options):
    """Ledger-wide Splitwise sum of the canonical bank/card movements."""
    return sum(delta for _row, delta in _ledger_splitwise_entries(conn, cur, **options))


def splitwise_changes_since_reset(currency="INR", limit=100):
    """Every row counted toward Splitwise since the total was last set, newest first.

    Lets the user compare the app with the Splitwise app row by row. Edits to
    rows that already existed (a category change, a merged duplicate) move the
    total without appearing as new rows, so that part is reported separately.
    """
    with connection() as conn:
        row = conn.execute(
            """SELECT baseline_amount_minor,baseline_ledger_minor,baseline_set_at
               FROM manual_splitwise_total WHERE currency=?""",
            (currency,),
        ).fetchone()
        if row is None or row["baseline_set_at"] is None or row["baseline_ledger_minor"] is None:
            return {"setAt": None, "baselineMinor": None, "changeMinor": 0, "otherChangeMinor": 0, "items": []}
        set_at = int(row["baseline_set_at"])
        entries = list(_ledger_splitwise_entries(conn, currency))
        change = sum(delta for _r, delta in entries) - int(row["baseline_ledger_minor"])
        snapshot = {
            r["transaction_id"]: int(r["delta_minor"])
            for r in conn.execute(
                "SELECT transaction_id,delta_minor FROM splitwise_baseline_rows WHERE currency=?", (currency,)
            ).fetchall()
        }

        def shape(r, delta, old=None):
            return {
                "id": r["id"], "timestamp": int(r["timestamp"]), "createdAt": int(r["created_at"] or 0),
                "description": r["merchant_or_payee"], "type": r["type"], "accountType": r["account_type"],
                "bank": r["bank"], "last4": r["account_last4"], "category": r["category"],
                "amountMinor": int(r["amount_minor"]), "deltaMinor": delta, "wasDeltaMinor": old,
            }

        if snapshot:
            # Exact comparison with the rows as they were when the total was set.
            items = [shape(r, delta) for r, delta in entries if delta and r["id"] not in snapshot]
            edits = [
                shape(r, delta - snapshot.get(str(r["id"]), 0), snapshot.get(str(r["id"]), 0))
                for r, delta in entries
                if str(r["id"]) in snapshot and delta != snapshot[str(r["id"])]
            ]
            current = {str(r["id"]) for r, _d in entries}
            for tid, old in snapshot.items():
                if tid in current:
                    continue
                gone = conn.execute(
                    """SELECT id,timestamp,created_at,merchant_or_payee,type,account_type,bank,account_last4,
                              category,amount_minor FROM transactions WHERE id=?""", (tid,)
                ).fetchone()
                if gone is not None:
                    edits.append(shape(gone, -old, old))
        else:
            # Total was set before snapshots existed: fall back to creation time.
            items = [shape(r, delta) for r, delta in entries if delta and int(r["created_at"] or 0) >= set_at]
            edits = []
        items.sort(key=lambda item: item["createdAt"], reverse=True)
        edits.sort(key=lambda item: abs(item["deltaMinor"]), reverse=True)
        listed = sum(item["deltaMinor"] for item in items)
        return {
            "setAt": set_at,
            "baselineMinor": int(row["baseline_amount_minor"]),
            "changeMinor": change,
            "otherChangeMinor": change - listed,
            "exact": bool(snapshot),
            "edits": edits[:40],
            "items": items[:limit],
        }


def rebuild_manual_splitwise_total(currency=None):
    """Rebuild the materialized Splitwise total from the canonical ledger.

    The transactions table is the source of truth for *changes*; the user's
    manual total is the baseline. The total is the manual amount plus whatever
    the ledger-wide Splitwise sum has changed by since that amount was set, so
    opening the app, retrying sync, restarting the API, duplicate repair or a
    late transfer match cannot make Splitwise drift or overwrite a reset.
    """
    with connection() as conn:
        currencies = [currency] if currency else [
            row["currency"]
            for row in conn.execute(
                "SELECT DISTINCT currency FROM transactions WHERE currency IS NOT NULL AND TRIM(currency)<>''"
            ).fetchall()
        ]

        for cur in currencies:
            ledger = _ledger_splitwise_total(conn, cur)
            row = conn.execute(
                """SELECT amount_minor,baseline_amount_minor,baseline_ledger_minor
                   FROM manual_splitwise_total WHERE currency=?""",
                (cur,),
            ).fetchone()

            if row is None:
                # No manual total was ever set: the ledger is the whole story.
                baseline_amount, baseline_ledger = 0, 0
            elif row["baseline_amount_minor"] is None or row["baseline_ledger_minor"] is None:
                # Value stored before baselines existed (possibly a manual
                # reset). Keep it and track changes from now on.
                baseline_amount, baseline_ledger = int(row["amount_minor"]), ledger
            else:
                baseline_amount = int(row["baseline_amount_minor"])
                baseline_ledger = int(row["baseline_ledger_minor"])

            total = baseline_amount + ledger - baseline_ledger
            conn.execute(
                """INSERT INTO manual_splitwise_total
                       (currency,amount_minor,updated_at,baseline_amount_minor,baseline_ledger_minor)
                   VALUES(?,?,?,?,?)
                   ON CONFLICT(currency) DO UPDATE SET
                       amount_minor=excluded.amount_minor,
                       updated_at=excluded.updated_at,
                       baseline_amount_minor=excluded.baseline_amount_minor,
                       baseline_ledger_minor=excluded.baseline_ledger_minor""",
                (cur, total, now_ms(), baseline_amount, baseline_ledger),
            )

    return get_manual_splitwise_total(currency or "INR")


def get_manual_splitwise_total(currency="INR"):
    """The Splitwise value shown to the user.

    Derived on every read: the manual baseline plus the change in the ledger's
    Splitwise sum since that baseline was set. The stored amount_minor is only
    a cache (and the fallback for legacy rows that have no baseline yet), so a
    stale incremental update can never be what the user sees.
    """
    with connection() as conn:
        row=conn.execute(
            """SELECT amount_minor,baseline_amount_minor,baseline_ledger_minor
               FROM manual_splitwise_total WHERE currency=?""",
            (currency,),
        ).fetchone()
        if row is None:
            # No manual total was ever set: the ledger is the whole story, but
            # with no transactions at all there is nothing to show yet.
            has_rows = conn.execute(
                "SELECT 1 FROM transactions WHERE currency=? LIMIT 1", (currency,)
            ).fetchone()
            return _ledger_splitwise_total(conn, currency) if has_rows else None
        if row["baseline_amount_minor"] is None or row["baseline_ledger_minor"] is None:
            return int(row["amount_minor"])
        ledger = _ledger_splitwise_total(conn, currency)
        return int(row["baseline_amount_minor"]) + ledger - int(row["baseline_ledger_minor"])


def upsert_splitwise_rule(item):
    with connection() as conn:
        conn.execute("""INSERT INTO splitwise_rules(id,merchant_pattern,group_id,split_mode,user_shares_json,enabled,created_at)
        VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET merchant_pattern=excluded.merchant_pattern,group_id=excluded.group_id,
        split_mode=excluded.split_mode,user_shares_json=excluded.user_shares_json,enabled=excluded.enabled""",
        (item["id"],item["merchant_pattern"],item["group_id"],item.get("split_mode","EQUAL"),item.get("user_shares_json"),
         1 if item.get("enabled",True) else 0,now_ms()))


def list_splitwise_rules():
    with connection() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM splitwise_rules WHERE enabled=1 ORDER BY merchant_pattern").fetchall()]


def get_splitwise_rule_for(merchant):
    if not merchant: return None
    needle=merchant.casefold()
    with connection() as conn:
        rows=conn.execute("SELECT * FROM splitwise_rules WHERE enabled=1 ORDER BY LENGTH(merchant_pattern) DESC").fetchall()
    for row in rows:
        if row["merchant_pattern"].casefold() in needle: return dict(row)
    return None


def record_splitwise_expense(transaction_id,expense_id,status="CREATED",error=None):
    with connection() as conn:
        conn.execute("""INSERT INTO splitwise_expenses(transaction_id,splitwise_expense_id,status,error,created_at,updated_at)
        VALUES(?,?,?,?,?,?) ON CONFLICT(transaction_id) DO UPDATE SET splitwise_expense_id=excluded.splitwise_expense_id,
        status=excluded.status,error=excluded.error,updated_at=excluded.updated_at""",
        (transaction_id,expense_id,status,error,now_ms(),now_ms()))


def splitwise_expense_for(transaction_id):
    with connection() as conn:
        row=conn.execute("SELECT * FROM splitwise_expenses WHERE transaction_id=?",(transaction_id,)).fetchone()
        return dict(row) if row else None


def splitwise_share_info(transaction_id):
    """How much of a salary credit counts toward Splitwise (None if not a salary credit)."""
    with connection() as conn:
        row = _resolve_transaction_row(conn, transaction_id)
        if row is None or row["status"] != "ACTIVE":
            return {"status": "NOT_FOUND", "transactionId": transaction_id}
        if not _is_salary_credit(row):
            return {"status": "NOT_SALARY", "transactionId": transaction_id}
        return {
            "status": "OK",
            "transactionId": row["id"],
            "amountMinor": int(row["amount_minor"]),
            "shareMinor": int(row["splitwise_amount_minor"] or 0),
        }


def set_splitwise_share(transaction_id, share_minor):
    """Choose how much of a salary credit counts toward Splitwise (0..amount)."""
    share_minor = int(share_minor)
    with connection() as conn:
        row = _resolve_transaction_row(conn, transaction_id)
        if row is None or row["status"] != "ACTIVE":
            return {"status": "NOT_FOUND", "transactionId": transaction_id}
        if not _is_salary_credit(row):
            return {"status": "NOT_SALARY", "transactionId": transaction_id}
        if share_minor < 0 or share_minor > int(row["amount_minor"]):
            return {"status": "INVALID_AMOUNT", "transactionId": transaction_id}
        previous = int(row["splitwise_amount_minor"] or 0)
        conn.execute(
            "UPDATE transactions SET splitwise_amount_minor=? WHERE id=?",
            (share_minor, row["id"]),
        )
    rebuild_manual_splitwise_total(row["currency"])
    return {
        "status": "UPDATED",
        "transactionId": row["id"],
        "amountMinor": int(row["amount_minor"]),
        "shareMinor": share_minor,
        "previousShareMinor": previous,
    }


def _is_salary_credit(row):
    return (
        str(row["category"] or "").strip().upper() == "SALARY"
        and str(row["type"] or "").strip().upper() == "CREDIT"
        and str(row["account_type"] or "").strip().upper() == "BANK_ACCOUNT"
    )
