"""Read-only ledger audit (synthetic data only)."""
from app import db
from app import ledger as L
from tests.test_self_transfer import sms_debit


def test_audit_explains_balances_and_changes_nothing(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "audit.db"))
    db.init_db()
    L.set_balance("axis", "Axis", "INR", "BANK_ACCOUNT", "AXIS", "1111", 1_000_000)
    L.set_manual_splitwise_total("INR", 0)
    t = sms_debit(ref=None)
    L.sync_transaction(t)
    L.rebuild_manual_splitwise_total()
    before = L.balances()
    out = L.ledger_audit(5)
    assert L.balances() == before
    acc = [a for a in out["accounts"] if a["id"] == "axis"][0]
    assert acc["driftMinor"] == 0
    assert acc["balanceMinor"] == 1_000_000 - 250_000
    assert out["recentTransactions"][0]["bank_delta"] == -250_000
    assert out["splitwise"]["ledgerSumMinor"] == 250_000
    assert out["splitwise"]["shownMinor"] == 250_000


def test_old_statement_rows_do_not_change_a_manually_set_balance(tmp_path, monkeypatch):
    import time
    from app.db import connection
    from app.ledger import migrations
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "stmt.db"))
    db.init_db()
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 500_000)
    L.set_manual_splitwise_total("INR", 0)
    old = int(time.time() * 1000) - 5 * 86_400_000
    t = sms_debit(bank="HDFC", last4="2222", ts=old, id="statement:abc", amount=100_000)
    L.sync_transaction(t)
    with connection() as conn:
        L.apply_transaction_to_account(conn, t, int(time.time() * 1000))
    L.rebuild_manual_splitwise_total()
    assert [a for a in L.balances() if a["id"] == "hdfc"][0]["balance_minor"] == 500_000
    assert L.get_manual_splitwise_total("INR") == 0


def test_migration_reverses_statement_rows_replayed_after_manual_edit(tmp_path, monkeypatch):
    import time
    from app.db import connection
    from app.ledger import migrations
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "mig.db"))
    db.init_db()
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 500_000)
    L.set_manual_splitwise_total("INR", 0)
    now = int(time.time() * 1000)
    t = sms_debit(bank="HDFC", last4="2222", ts=now - 86_400_000, id="statement:old", amount=100_000)
    L.sync_transaction(t)
    with connection() as conn:  # simulate the old behaviour: replayed with a delta
        acc = conn.execute("SELECT id FROM accounts WHERE last4='2222'").fetchone()["id"]
        conn.execute("INSERT INTO balance_adjustments VALUES('statement:old',?,-100000,?)", (acc, now))
        conn.execute("UPDATE accounts SET balance_minor=400000")
    assert migrations.migrate_statement_reconciled_reversal() == 1
    assert [a for a in L.balances() if a["id"] == "hdfc"][0]["balance_minor"] == 500_000
    assert migrations.migrate_statement_reconciled_reversal() == 0


def test_editing_the_bank_balance_again_does_not_change_splitwise(tmp_path, monkeypatch):
    import time
    from app.db import connection
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "sw.db"))
    db.init_db()
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 500_000)
    L.set_manual_splitwise_total("INR", 0)
    t = sms_debit(bank="HDFC", last4="2222", ts=int(time.time() * 1000) - 86_400_000,
                  id="statement:old", amount=100_000)
    L.sync_transaction(t)  # stored after the edit, dated before it: no balance effect
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 0
    time.sleep(0.01)
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 450_000)  # second manual edit
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 0


def test_splitwise_rule_migration_keeps_the_shown_value(tmp_path, monkeypatch):
    import time
    from app.ledger import migrations
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "swm.db"))
    db.init_db()
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 500_000)
    t = sms_debit(bank="HDFC", last4="2222", ts=int(time.time() * 1000) - 86_400_000,
                  id="statement:old", amount=100_000)
    L.sync_transaction(t)
    time.sleep(0.01)
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 450_000)
    # State left by the old bug: the row counted once the account was edited again,
    # and the user typed the Splitwise total they wanted on top of it (baseline
    # recorded under the legacy rule).
    from app.db import connection
    from app.ledger.splitwise import _ledger_splitwise_total
    L.set_manual_splitwise_total("INR", 777_000)
    with connection() as conn:
        legacy = _ledger_splitwise_total(conn, "INR", legacy_statement_rule=True)
        assert legacy != _ledger_splitwise_total(conn, "INR")
        conn.execute("UPDATE manual_splitwise_total SET baseline_ledger_minor=?", (legacy,))
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") != 777_000  # the new rule alone would move it
    assert migrations.migrate_splitwise_statement_rule() is True
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 777_000
    assert migrations.migrate_splitwise_statement_rule() is False


def test_manually_marked_card_payment_pairs_with_the_bank_debit(tmp_path, monkeypatch):
    """The phone's 'this was a card bill payment' button creates this card credit."""
    from types import SimpleNamespace
    from app.db import connection
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "mark.db"))
    db.init_db()
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 1_000_000)
    L.set_balance("c8001", "ICICI Credit Card", "INR", "CREDIT_CARD", "ICICI", "8001", 300_000, 300_000)
    L.set_manual_splitwise_total("INR", 0)
    ts = 1_800_000_000_000
    debit = sms_debit(bank="HDFC", last4="2222", ts=ts, id="sms:pay", amount=300_000, ref="RRN123456")
    credit = SimpleNamespace(
        id="manual-card-payment:7", amountMinor=300_000, currency="INR", type="CREDIT",
        paymentMethod="UPI", accountType="CREDIT_CARD", bank="ICICI", merchantOrPayee="Credit Card Bill Payment",
        accountLast4="8001", reference="RRN123456", timestamp=ts, category="TRANSFER", confidence=1.0)
    for t in (debit, credit):
        L.sync_transaction(t)
    L.match_internal_transfers()
    L.rebuild_manual_splitwise_total()
    with connection() as conn:
        card = conn.execute("SELECT balance_minor,bill_balance_minor,bill_locked_at FROM accounts WHERE id='c8001'").fetchone()
    assert card["bill_balance_minor"] == 0 and card["balance_minor"] == 0
    assert card["bill_locked_at"] > 0
    assert L.get_manual_splitwise_total("INR") == 0


def _card_credit(tid, amount, ts, ref=None):
    from types import SimpleNamespace
    return SimpleNamespace(
        id=tid, amountMinor=amount, currency="INR", type="CREDIT", paymentMethod="UPI",
        accountType="CREDIT_CARD", bank="ICICI", merchantOrPayee="Credit Card Bill Payment",
        accountLast4="8001", reference=ref, timestamp=ts, category="TRANSFER", confidence=1.0)


def test_partial_payment_lowers_the_bill_by_what_was_paid_and_locks_it(tmp_path, monkeypatch):
    from app.db import connection
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "partial.db"))
    db.init_db()
    L.set_balance("hdfc", "HDFC", "INR", "BANK_ACCOUNT", "HDFC", "2222", 1_000_000)
    L.set_balance("c8001", "ICICI Credit Card", "INR", "CREDIT_CARD", "ICICI", "8001", 500_000, 300_000)
    L.set_manual_splitwise_total("INR", 0)
    ts = 1_800_000_000_000
    L.sync_transaction(sms_debit(bank="HDFC", last4="2222", ts=ts, id="sms:pay", amount=100_000, ref="R1"))
    L.sync_transaction(_card_credit("manual-card-payment:1", 100_000, ts, "R1"))
    L.match_internal_transfers()
    L.rebuild_manual_splitwise_total()
    with connection() as conn:
        card = conn.execute("SELECT balance_minor,bill_balance_minor,bill_locked_at FROM accounts WHERE id='c8001'").fetchone()
    assert card["bill_balance_minor"] == 200_000      # 3000 bill - 1000 paid
    assert card["balance_minor"] == 400_000           # active spend 2000 untouched
    assert card["bill_locked_at"] > 0
    assert L.get_manual_splitwise_total("INR") == 0   # own-bank payment is neutral


def test_a_card_payment_made_by_someone_else_lowers_splitwise(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "friend.db"))
    db.init_db()
    L.set_balance("c8001", "ICICI Credit Card", "INR", "CREDIT_CARD", "ICICI", "8001", 500_000, 300_000)
    L.set_manual_splitwise_total("INR", 500_000)
    L.sync_transaction(_card_credit("sms:friend-paid", 200_000, 1_800_000_000_000))
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 300_000


def test_card_payment_naming_only_the_issuer_goes_to_the_one_card_that_owes(tmp_path, monkeypatch):
    """SBI confirmations say 'your SBI Credit Card' without digits."""
    from app.db import connection
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "issuer.db"))
    db.init_db()
    L.set_balance("sbi-card-0065", "SBI Credit Card", "INR", "CREDIT_CARD", "SBI", "0065", 177_000, 177_000)
    L.set_balance("sbi-card-7345", "SBI Credit Card", "INR", "CREDIT_CARD", "SBI", "7345", 0, 0)
    credit = _card_credit("sms:sbi-paid", 177_010, 1_800_000_000_000)
    credit.bank, credit.accountLast4, credit.paymentMethod = "SBI", None, "BANK_TRANSFER"
    L.sync_transaction(credit)
    with connection() as conn:
        paid = conn.execute("SELECT balance_minor,bill_balance_minor FROM accounts WHERE id='sbi-card-0065'").fetchone()
        other = conn.execute("SELECT balance_minor FROM accounts WHERE id='sbi-card-7345'").fetchone()
    assert paid["bill_balance_minor"] == 0
    assert paid["balance_minor"] == -10      # 1770.10 paid against 1770.00: a 10 paise credit
    assert other["balance_minor"] == 0


def test_equal_card_payments_minutes_apart_are_separate_payments():
    from app.ledger.dedup import _rows_are_duplicate
    ts = 1_800_000_000_000

    def row(i, secs, ref):
        return {
            "id": str(i), "currency": "INR", "bank": "AXIS", "account_last4": "9206", "reference": ref,
            "type": "CREDIT", "account_type": "CREDIT_CARD", "amount_minor": 500_000,
            "payment_method": "UNKNOWN", "merchant_or_payee": "Credit Card Bill Payment",
            "timestamp": ts + secs * 1000,
        }

    sms_credit = row(1, 0, None)          # the card's own SMS: no reference
    marked_credit = row(2, 31, "RRN-A")   # marked by the user: carries the debit's reference
    assert not _rows_are_duplicate(sms_credit, marked_credit)
    assert not _rows_are_duplicate(sms_credit, row(3, 40, None))   # two SMS payments of 5,000
    assert not _rows_are_duplicate(marked_credit, row(4, 20, "RRN-B"))
    # The same event with the same reference is still one event.
    assert _rows_are_duplicate(marked_credit, row(5, 60, "RRN-A"))


def _ist_ms(year, month, day, hour=12):
    import datetime
    ist = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    return int(datetime.datetime(year, month, day, hour, tzinfo=ist).timestamp() * 1000)


def _emi_setup(tmp_path, monkeypatch, balance=3_000_000):
    from app.db import connection
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "emi.db"))
    db.init_db()
    L.set_balance("axis", "Axis", "INR", "BANK_ACCOUNT", "AXIS", "3370", balance)
    L.set_manual_splitwise_total("INR", 0)
    with connection() as conn:  # the loan rule applies to rows stored after it was set up
        conn.execute("UPDATE emi_loans SET created_at=0")


def test_emi_is_reserved_from_the_first_to_the_due_day(tmp_path, monkeypatch):
    from app.db import connection
    from app.ledger.emi import emi_reservations
    _emi_setup(tmp_path, monkeypatch)
    with connection() as conn:
        assert emi_reservations(conn, "INR", _ist_ms(2026, 12, 1, 1))[0]["amountMinor"] == 1_110_000
        assert emi_reservations(conn, "INR", _ist_ms(2026, 12, 10, 23))[0]["amountMinor"] == 1_110_000
        assert emi_reservations(conn, "INR", _ist_ms(2026, 12, 11, 1)) == []
        assert emi_reservations(conn, "INR", _ist_ms(2026, 11, 30, 23)) == []


def test_emi_reserve_stops_once_the_debit_lands(tmp_path, monkeypatch):
    from app.db import connection
    from app.ledger.emi import emi_reservations
    _emi_setup(tmp_path, monkeypatch)
    at = _ist_ms(2026, 12, 5)
    L.sync_transaction(sms_debit(bank="AXIS", last4="3370", ts=_ist_ms(2026, 12, 3), id="other1", amount=1_110_001))
    with connection() as conn:
        assert len(emi_reservations(conn, "INR", at)) == 1  # a different amount is not the EMI
    L.sync_transaction(sms_debit(bank="AXIS", last4="3370", ts=_ist_ms(2026, 12, 4), id="emi1", amount=1_110_000))
    with connection() as conn:
        assert emi_reservations(conn, "INR", at) == []


def test_a_payment_to_a_person_of_the_same_amount_is_not_the_emi(tmp_path, monkeypatch):
    from app.db import connection
    from app.ledger.emi import emi_reservations
    _emi_setup(tmp_path, monkeypatch)
    friend = sms_debit(bank="AXIS", last4="3370", ts=_ist_ms(2026, 12, 4), id="friend", amount=1_110_000)
    friend.merchantOrPayee = "RAHUL K"
    L.sync_transaction(friend)
    L.rebuild_manual_splitwise_total()
    with connection() as conn:
        assert len(emi_reservations(conn, "INR", _ist_ms(2026, 12, 5))) == 1
    assert L.get_manual_splitwise_total("INR") == 1_110_000


def test_emi_shortfall_flags_a_low_axis_balance(tmp_path, monkeypatch):
    from app.db import connection
    from app.ledger.emi import emi_reservations
    _emi_setup(tmp_path, monkeypatch, balance=500_000)
    with connection() as conn:
        out = emi_reservations(conn, "INR", _ist_ms(2026, 12, 6))
    assert out[0]["shortfall"] is True
    assert out[0]["accountBalanceMinor"] == 500_000


def test_emi_debit_and_loan_credit_stay_out_of_splitwise(tmp_path, monkeypatch):
    _emi_setup(tmp_path, monkeypatch)
    debit = sms_debit(bank="AXIS", last4="3370", ts=_ist_ms(2026, 12, 10), id="emi-debit", amount=1_110_000)
    L.sync_transaction(debit)
    from tests.test_self_transfer import Tx
    credit = Tx(id="loan-credit", amountMinor=1_110_000, type="CREDIT", bank="AXIS", accountLast4="8590",
                reference=None, timestamp=_ist_ms(2026, 12, 11))
    L.sync_transaction(credit)
    L.sync_transaction(sms_debit(bank="AXIS", last4="3370", ts=_ist_ms(2026, 12, 10), id="shop", amount=50_000))
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 50_000


def test_rows_stored_before_the_loan_rule_keep_counting(tmp_path, monkeypatch):
    from app.db import connection
    _emi_setup(tmp_path, monkeypatch)
    L.sync_transaction(sms_debit(bank="AXIS", last4="3370", ts=_ist_ms(2026, 12, 10), id="old-emi", amount=1_110_000))
    with connection() as conn:
        conn.execute("UPDATE emi_loans SET created_at=?", (2**60,))
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 1_110_000


def test_summary_subtracts_the_reserve(tmp_path, monkeypatch):
    from app.ledger import queries
    _emi_setup(tmp_path, monkeypatch)
    monkeypatch.setattr(queries, "emi_reservations",
                        lambda conn, currency: __import__("app.ledger.emi", fromlist=["x"]).emi_reservations(conn, currency, _ist_ms(2026, 12, 5)))
    out = L.true_available("INR")
    assert out["emiReservedMinor"] == 1_110_000
    assert out["trueAvailableMinor"] == out["bankCashMinor"] + out["splitwiseReceivableMinor"] - out["creditCardOutstandingMinor"] - 1_110_000



def test_changes_since_reset_lists_new_rows_and_reconciles_to_the_total(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "chg.db"))
    db.init_db()
    L.set_balance("axis", "Axis", "INR", "BANK_ACCOUNT", "AXIS", "1111", 1_000_000)
    L.sync_transaction(sms_debit(ref=None, amount=70_000, id="sms:before"))
    L.set_manual_splitwise_total("INR", 5_000_000)
    assert L.splitwise_changes_since_reset("INR")["items"] == []
    import time
    time.sleep(0.01)
    L.sync_transaction(sms_debit(ref=None, amount=38_000, id="sms:after1"))
    L.sync_transaction(sms_debit(ref=None, amount=9_000, id="sms:after2", ts=sms_debit().timestamp + 600_000))
    L.rebuild_manual_splitwise_total()
    out = L.splitwise_changes_since_reset("INR")
    assert [i["id"] for i in out["items"]] == ["sms:after2", "sms:after1"]
    assert out["changeMinor"] == 47_000 and out["otherChangeMinor"] == 0
    assert L.get_manual_splitwise_total("INR") == 5_000_000 + 47_000


def test_an_edit_to_an_older_row_shows_up_as_other_change(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "chg2.db"))
    db.init_db()
    L.set_balance("axis", "Axis", "INR", "BANK_ACCOUNT", "AXIS", "1111", 1_000_000)
    old = sms_debit(ref=None, amount=70_000, id="sms:old")
    L.sync_transaction(old)
    L.set_manual_splitwise_total("INR", 5_000_000)
    old.category = "OTHER"
    L.sync_transaction(old)
    L.rebuild_manual_splitwise_total()
    out = L.splitwise_changes_since_reset("INR")
    assert out["items"] == [] and out["changeMinor"] == -70_000 and out["otherChangeMinor"] == -70_000
    assert out["exact"] is True
    assert [(e["id"], e["wasDeltaMinor"], e["deltaMinor"]) for e in out["edits"]] == [("sms:old", 70_000, -70_000)]


def test_changes_report_is_empty_when_the_total_was_never_set(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "chg3.db"))
    db.init_db()
    assert L.splitwise_changes_since_reset("INR")["setAt"] is None


def test_a_closed_card_with_nothing_owed_is_removed_but_its_history_stays(tmp_path, monkeypatch):
    from app.db import connection
    from app.ledger import migrations
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "closed.db"))
    db.init_db()
    L.set_balance("old", "Old Card", "INR", "CREDIT_CARD", "ACME", "5145", 0)
    L.set_manual_splitwise_total("INR", 0)
    from tests.test_self_transfer import Tx
    L.sync_transaction(Tx(id="old:spend", amountMinor=36_654, type="DEBIT", bank="ACME", accountLast4="5145",
                          accountType="CREDIT_CARD", paymentMethod="CARD", reference=None, timestamp=1_800_000_000_000))
    with connection() as conn:
        conn.execute("UPDATE accounts SET balance_minor=0 WHERE last4='5145'")
    L.rebuild_manual_splitwise_total()
    before = L.get_manual_splitwise_total("INR")
    assert migrations.migrate_remove_closed_card("ACME", "5145") is True
    with connection() as conn:
        assert conn.execute("SELECT COUNT(*) c FROM accounts WHERE last4='5145' AND account_type='CREDIT_CARD'").fetchone()["c"] == 0
        assert conn.execute("SELECT COUNT(*) c FROM transactions WHERE id='old:spend'").fetchone()["c"] == 1
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == before
    assert migrations.migrate_remove_closed_card("ACME", "5145") is False


def test_a_closed_card_that_still_owes_money_is_kept(tmp_path, monkeypatch):
    from app.db import connection
    from app.ledger import migrations
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "owing.db"))
    db.init_db()
    L.set_balance("old", "Old Card", "INR", "CREDIT_CARD", "ACME", "5145", 50_000)
    assert migrations.migrate_remove_closed_card("ACME", "5145") is False
    with connection() as conn:
        assert conn.execute("SELECT COUNT(*) c FROM accounts WHERE last4='5145'").fetchone()["c"] == 1


def test_phone_category_edit_reaches_a_gmail_only_row_but_a_gmail_rescan_does_not_undo_it(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "gm.db"))
    db.init_db()
    L.set_balance("axis", "Axis", "INR", "BANK_ACCOUNT", "AXIS", "1111", 1_000_000)
    L.set_manual_splitwise_total("INR", 5_000_000)
    row = sms_debit(ref="777", amount=10_000, id="gmail:abc")
    row.category = "GROCERIES"
    L.sync_transaction(row)
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 5_010_000
    row.category = "OTHER"
    L.sync_transaction(row, category_edit=True)
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 5_000_000
    row.category = "GROCERIES"
    L.sync_transaction(row)  # Gmail re-scan: parser guess again
    L.rebuild_manual_splitwise_total()
    assert L.get_manual_splitwise_total("INR") == 5_000_000


def test_an_id_owned_by_an_old_row_gets_its_own_row_and_edits_follow_it(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "col.db"))
    db.init_db()
    L.set_balance("axis", "Axis", "INR", "BANK_ACCOUNT", "AXIS", "1111", 1_000_000)
    old = sms_debit(ref="111111", amount=10_000, id="477")
    old.category = "OTHER"
    L.sync_transaction(old)
    L.set_manual_splitwise_total("INR", 5_000_000)
    new = sms_debit(ref="229275321545", amount=10_000, id="477", ts=old.timestamp + 40 * 24 * 3600 * 1000)
    new.category = "GROCERIES"
    L.sync_transaction(new)
    L.rebuild_manual_splitwise_total()
    from app.db import connection
    with connection() as conn:
        rows = {r["id"]: (r["reference"], r["category"]) for r in conn.execute("SELECT id,reference,category FROM transactions")}
    assert rows["477"] == ("111111", "OTHER")  # old row untouched
    assert len(rows) == 2 and any(i.startswith("477~") for i in rows)
    assert L.get_manual_splitwise_total("INR") == 5_010_000
    new.category = "OTHER"
    L.sync_transaction(new, category_edit=True)
    L.sync_transaction(new, category_edit=True)  # repeat lands on the same row
    L.rebuild_manual_splitwise_total()
    with connection() as conn:
        assert conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0] == 2
    assert L.get_manual_splitwise_total("INR") == 5_000_000
